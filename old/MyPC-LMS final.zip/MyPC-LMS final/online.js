title = document.getElementsByClassName("block-title-txt")[1]
console.log(title)
title.insertAdjacentText('afterbegin', 'その他');